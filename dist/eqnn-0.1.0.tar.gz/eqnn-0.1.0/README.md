This project is a project.

First run 'poetry install' to install the package
Then run 'python3 main.py -m DATA.N=20,40 non_equivariance=0,1,2'

To install new packages within the poetry venv and automatically update the toml:
1. activate the venv with 'poetry shell'
2. run 'poetry add package_name'

To install new packages within the poetry venv withouf updating the toml:
1. activate the venv with 'poetry shell'
2. run 'pip install package_name'
